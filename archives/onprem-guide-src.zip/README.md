# 대기업 에이전트 배포 속성 가이드북 — 소스

- `dist/onprem-agent-deploy-guide.html` : 완성본 (단일 파일, 오프라인 동작)
- `src/*.md` : 마크다운 원본 (파일명 순서 = 목차 순서)
- `theme/style.css`, `theme/app.js` : 테마·스크립트 (빌드 시 인라인)
- `shots/*.png` : 실제 화면 캡처 (빌드 시 base64 인라인)
- `lab/` : 실습 파일 전체 (부록 F는 여기서 자동 생성)
- `build.py` : 빌드 스크립트

## 다시 빌드

    pip install markdown pygments pyyaml pymdown-extensions
    python3 build.py --check      # YAML·셸 블록 기계 검사 + HTML 생성

## 마크다운 규칙

- 상자: `!!! why|expect|fail|eye|note|warn|tip|check|os|rollback|unverified|verified|say|checkpoint`
- 화면 목업: ```screen 블록, 첫 줄 `# 제목`
- 파일명 탭: 코드 블록 첫 줄 `#file: 경로`
- 체크박스: `- [ ] 항목` (브라우저 localStorage에 저장)
- 부록 F: `{{LAB_TREE}}`, `{{LAB_FILES}}` 자리표시자가 `lab/`에서 채워짐
